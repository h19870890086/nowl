<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { ElInput } from 'element-plus'
import type { AdminScopeBindingItem, IamRoleItem, UserRoleBindingItem } from '@/api/modules/admin'
import UniModal from '@/components/UniModal.vue'

const props = defineProps<{
  canViewIamRole: boolean
  canViewIamUserRole: boolean
  canManageIamUserRole: boolean
  canViewIamScope: boolean
  canManageIamScope: boolean
  iamRoles: IamRoleItem[]
  iamUserIdInput: string
  iamTargetUserId: number | null
  userRoleBindings: UserRoleBindingItem[]
  adminScopeBindings: AdminScopeBindingItem[]
}>()

const emit = defineEmits<{
  (e: 'update:iamUserIdInput', value: string): void
  (e: 'query-user'): void
  (e: 'grant-role', roleCode: string, reason: string): void
  (e: 'revoke-role', bindingId: number): void
  (e: 'add-scope', scopeType: string, schoolCode: string, campusCode: string): void
  (e: 'disable-scope', bindingId: number): void
}>()

const iamUserIdModel = computed({
  get: () => props.iamUserIdInput,
  set: (value: string) => emit('update:iamUserIdInput', value),
})

// Grant role dialog
const showGrantDialog = ref(false)
const grantRoleCode = ref('')
const grantReason = ref('')
const grantRoleFilter = ref('')

const filteredRoles = computed(() => {
  if (!grantRoleFilter.value) return props.iamRoles
  const f = grantRoleFilter.value.toLowerCase()
  return props.iamRoles.filter(r =>
    r.roleCode.toLowerCase().includes(f) ||
    (r.roleName && r.roleName.toLowerCase().includes(f))
  )
})

const selectedRoleName = computed(() => {
  const r = props.iamRoles.find(r => r.roleCode === grantRoleCode.value)
  return r ? `${r.roleName || r.roleCode} (${r.roleCode})` : grantRoleCode.value || '请选择角色'
})

function openGrantDialog() {
  grantRoleCode.value = ''
  grantReason.value = ''
  grantRoleFilter.value = ''
  showGrantDialog.value = true
}

function confirmGrant() {
  if (!grantRoleCode.value) return
  emit('grant-role', grantRoleCode.value, grantReason.value || '')
  showGrantDialog.value = false
}

// Add scope dialog
const showScopeDialog = ref(false)
const scopeType = ref('SCHOOL')
const scopeSchoolCode = ref('')
const scopeCampusCode = ref('')
const scopeTypes = ['ALL', 'SCHOOL', 'CAMPUS']

function openScopeDialog() {
  scopeType.value = 'SCHOOL'
  scopeSchoolCode.value = ''
  scopeCampusCode.value = ''
  showScopeDialog.value = true
}

function confirmScope() {
  emit('add-scope', scopeType.value, scopeSchoolCode.value || '', scopeCampusCode.value || '')
  showScopeDialog.value = false
}
</script>
</script>

<template>
  <div class="admin-panel space-y-6">
    <div v-if="!canViewIamRole && !canViewIamUserRole && !canViewIamScope" class="py-16 text-center text-slate-400">
      当前账号暂无IAM权限中心访问权限
    </div>

    <template v-else>
      <div class="grid grid-cols-2 gap-6">
        <div v-if="canViewIamRole" class="rounded-2xl border border-warm-100 p-5 bg-gradient-to-br from-slate-50 to-warm-50/60">
          <h3 class="text-sm font-bold text-slate-700 mb-3">系统角色</h3>
          <div class="space-y-2 max-h-56 overflow-auto">
            <div
              v-for="role in iamRoles"
              :key="role.roleId"
              class="flex items-center justify-between px-3 py-2 rounded-xl bg-white border border-warm-100"
            >
              <div>
                <p class="text-sm font-semibold text-slate-700">{{ role.roleName || role.roleCode }}</p>
                <p class="text-xs text-slate-400">{{ role.roleCode }}</p>
              </div>
              <span class="text-xs text-slate-500">L{{ role.roleLevel }}</span>
            </div>
            <div v-if="iamRoles.length === 0" class="text-sm text-slate-400 py-8 text-center">暂无角色数据</div>
          </div>
        </div>

        <div class="rounded-2xl border border-warm-100 p-5 bg-gradient-to-br from-slate-50 to-warm-50/60" :class="canViewIamRole ? '' : 'col-span-2'">
          <h3 class="text-sm font-bold text-slate-700 mb-3">查询目标管理员</h3>
          <div class="flex gap-3 items-center">
            <el-input v-model="iamUserIdModel" placeholder="输入用户ID" class="w-64" clearable />
            <button @click="emit('query-user')" class="px-4 py-2 bg-gradient-to-r from-warm-500 to-warm-400 text-white rounded-xl text-sm font-semibold hover:shadow-lg hover:shadow-warm-200 transition-all">
              查询
            </button>
          </div>
          <p class="text-xs text-slate-400 mt-3">当前用户：{{ iamTargetUserId || '-' }}</p>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-6">
        <div v-if="canViewIamUserRole" class="rounded-2xl border border-warm-100 p-5 bg-white">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-bold text-slate-700">用户角色绑定</h3>
            <button v-if="canManageIamUserRole" @click="openGrantDialog" class="px-3 py-1.5 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-lg text-xs font-semibold hover:shadow-lg hover:shadow-emerald-200 transition-all">
              授予角色
            </button>
          </div>
          <div v-if="userRoleBindings.length === 0" class="text-sm text-slate-400 py-10 text-center">暂无角色绑定</div>
          <div v-else class="space-y-2 max-h-72 overflow-auto">
            <div
              v-for="binding in userRoleBindings"
              :key="binding.id"
              class="flex items-center justify-between p-3 rounded-xl bg-slate-50/80 border border-warm-100"
            >
              <div>
                <p class="text-sm font-semibold text-slate-700">{{ binding.roleName || binding.roleCode }}</p>
                <p class="text-xs text-slate-400">绑定ID: {{ binding.id }}</p>
              </div>
              <button
                v-if="canManageIamUserRole"
                @click="emit('revoke-role', binding.id)"
                class="px-3 py-1.5 bg-white border border-red-200 text-red-500 rounded-lg text-xs font-medium hover:bg-red-50"
              >
                撤销
              </button>
            </div>
          </div>
        </div>

        <div v-if="canViewIamScope" class="rounded-2xl border border-warm-100 p-5 bg-white">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-bold text-slate-700">管理范围绑定</h3>
            <button v-if="canManageIamScope" @click="openScopeDialog" class="px-3 py-1.5 bg-gradient-to-r from-warm-500 to-warm-400 text-white rounded-lg text-xs font-semibold hover:shadow-lg hover:shadow-warm-200 transition-all">
              新增范围
            </button>
          </div>
          <div v-if="adminScopeBindings.length === 0" class="text-sm text-slate-400 py-10 text-center">暂无范围绑定</div>
          <div v-else class="space-y-2 max-h-72 overflow-auto">
            <div
              v-for="binding in adminScopeBindings"
              :key="binding.bindingId"
              class="flex items-center justify-between p-3 rounded-xl bg-slate-50/80 border border-warm-100"
            >
              <div>
                <p class="text-sm font-semibold text-slate-700">{{ binding.scopeType }}</p>
                <p class="text-xs text-slate-400">{{ binding.schoolCode || '-' }} / {{ binding.campusCode || '-' }}</p>
              </div>
              <button
                v-if="canManageIamScope"
                @click="emit('disable-scope', binding.bindingId)"
                class="px-3 py-1.5 bg-white border border-red-200 text-red-500 rounded-lg text-xs font-medium hover:bg-red-50"
              >
                关闭
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- 授予角色对话框 -->
      <UniModal :show="showGrantDialog" title="授予角色" @close="showGrantDialog = false">
        <div class="space-y-4">
          <div>
            <label class="text-xs font-bold text-slate-500 block mb-2">选择角色</label>
            <input v-model="grantRoleFilter" type="text" placeholder="搜索角色..." class="w-full px-3 py-2 border border-warm-200 rounded-xl text-sm mb-2 outline-none focus:border-warm-400" />
            <div class="max-h-48 overflow-auto border border-warm-100 rounded-xl divide-y divide-warm-50">
              <div
                v-for="role in filteredRoles"
                :key="role.roleId"
                @click="grantRoleCode = role.roleCode"
                class="px-3 py-2.5 cursor-pointer hover:bg-warm-50 transition-colors flex items-center justify-between"
                :class="grantRoleCode === role.roleCode ? 'bg-warm-50 border-l-2 border-warm-500' : ''"
              >
                <div>
                  <p class="text-sm font-semibold text-slate-700">{{ role.roleName || role.roleCode }}</p>
                  <p class="text-xs text-slate-400">{{ role.roleCode }} · 等级 {{ role.roleLevel }}</p>
                </div>
                <span v-if="grantRoleCode === role.roleCode" class="text-warm-500 text-lg">&#10003;</span>
              </div>
              <div v-if="filteredRoles.length === 0" class="px-3 py-4 text-center text-sm text-slate-400">无匹配角色</div>
            </div>
          </div>
          <div>
            <label class="text-xs font-bold text-slate-500 block mb-1">授予原因（可选）</label>
            <input v-model="grantReason" type="text" placeholder="如：任命为校区管理员" class="w-full px-3 py-2 border border-warm-200 rounded-xl text-sm outline-none focus:border-warm-400" />
          </div>
          <p class="text-xs text-warm-500">当前选择：{{ selectedRoleName }}</p>
        </div>
        <template #footer>
          <button @click="showGrantDialog = false" class="px-4 py-2 border border-slate-200 rounded-xl text-sm text-slate-500 hover:bg-slate-50">取消</button>
          <button @click="confirmGrant" :disabled="!grantRoleCode" class="px-4 py-2 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl text-sm font-semibold disabled:opacity-40">确认授予</button>
        </template>
      </UniModal>

      <!-- 新增范围对话框 -->
      <UniModal :show="showScopeDialog" title="新增管理范围" @close="showScopeDialog = false">
        <div class="space-y-4">
          <div>
            <label class="text-xs font-bold text-slate-500 block mb-2">范围类型</label>
            <div class="flex gap-2">
              <button
                v-for="st in scopeTypes"
                :key="st"
                @click="scopeType = st"
                class="px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                :class="scopeType === st ? 'bg-warm-500 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'"
              >{{ st }}</button>
            </div>
          </div>
          <div v-if="scopeType !== 'ALL'">
            <label class="text-xs font-bold text-slate-500 block mb-1">学校编码</label>
            <input v-model="scopeSchoolCode" type="text" placeholder="如：SC0143" class="w-full px-3 py-2 border border-warm-200 rounded-xl text-sm outline-none focus:border-warm-400" />
          </div>
          <div v-if="scopeType === 'CAMPUS'">
            <label class="text-xs font-bold text-slate-500 block mb-1">校区编码（可选）</label>
            <input v-model="scopeCampusCode" type="text" placeholder="如：CP0430" class="w-full px-3 py-2 border border-warm-200 rounded-xl text-sm outline-none focus:border-warm-400" />
          </div>
        </div>
        <template #footer>
          <button @click="showScopeDialog = false" class="px-4 py-2 border border-slate-200 rounded-xl text-sm text-slate-500 hover:bg-slate-50">取消</button>
          <button @click="confirmScope" :disabled="!scopeType || (scopeType !== 'ALL' && !scopeSchoolCode)" class="px-4 py-2 bg-gradient-to-r from-warm-500 to-warm-400 text-white rounded-xl text-sm font-semibold disabled:opacity-40">确认添加</button>
        </template>
      </UniModal>
    </template>
  </div>
</template>

<style scoped>
.admin-panel :deep(.el-input__wrapper) {
  border-radius: 12px;
  box-shadow: 0 0 0 1px rgba(141, 110, 99, 0.25);
}

.admin-panel :deep(.el-input__wrapper:hover) {
  box-shadow: 0 0 0 1px rgba(141, 110, 99, 0.45);
}

.admin-panel :deep(.el-input.is-focus .el-input__wrapper) {
  box-shadow: 0 0 0 2px rgba(255, 112, 67, 0.24);
}
</style>
